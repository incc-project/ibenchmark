# tesseract-ocr/test
Repository for binaries (images, tessdata) required for testing Tesseract.

This repository should be included as a submodule in tesseract-ocr/tesseract.
