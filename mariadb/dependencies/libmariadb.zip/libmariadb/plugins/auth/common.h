/** Maximal length of the target name */
#define PRINCIPAL_NAME_MAX 256
/** Maximal length of the mech string */
#define MECH_NAME_MAX 30
