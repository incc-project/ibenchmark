wolfSSL sample application project for Renesas RSK+RX65N-2MB evaluation board
======

<br>

A sample program for evaluating wolfSSL targeting the Renesas RSK+RX65N-2MB evaluation board is provided. For details on the program, refer to the following documents included in the package.

+ InstructionManualForExample_RSK+RX65N-2MB_JP.pdf (Japanese)
+ InstructionManualForExample_RSK+RX65N-2MB_EN.pdf (English）
