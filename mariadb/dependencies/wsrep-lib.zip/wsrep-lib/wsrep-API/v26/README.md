# Write Set Replication API specification

Building:
```
cmake [-DCMAKE_BUILD_TYPE=Debug|Release] . && make [VERBOSE=1]
```
in top directory.
